import assert from "node:assert/strict";
import { test } from "node:test";
import { deflateSync } from "node:zlib";
import type { AssetRef, GameBlueprint } from "../src/lib/blueprint/types";
import { validateBlueprint } from "../src/lib/blueprint/validate";
import { draftToBlueprint } from "../src/lib/creation/blueprint-from-draft";
import { createDefaultDraft } from "../src/lib/creation/draft";
import { decodeArtwork, parseDataUrl } from "../src/lib/assets/decode";
import {
  findAssetUsage,
  safeUnbindAsset,
  assignAsset,
  detectAssetFormat,
} from "../src/lib/assets/usage";

const NOW = "2026-01-01T00:00:00.000Z";

function makePng(colorType = 6, width = 64, height = 64): Buffer {
  const table = Array.from({ length: 256 }, (_, n) => {
    for (let i = 0; i < 8; i++) n = n & 1 ? 0xedb88320 ^ (n >>> 1) : n >>> 1;
    return n >>> 0;
  });
  const crc = (b: Buffer) => {
    let c = 0xffffffff;
    for (const x of b) c = table[(c ^ x) & 255] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  };
  const chunk = (type: string, data: Buffer) => {
    const n = Buffer.from(type);
    const len = Buffer.alloc(4);
    const sum = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    sum.writeUInt32BE(crc(Buffer.concat([n, data])));
    return Buffer.concat([len, n, data, sum]);
  };

  const head = Buffer.alloc(13);
  head.writeUInt32BE(width, 0);
  head.writeUInt32BE(height, 4);
  head[8] = 8; // bit depth
  head[9] = colorType; // 6 = RGBA (alpha), 2 = RGB (opaque)

  const bytesPerPixel = colorType === 6 ? 4 : 3;
  const row = Buffer.concat([
    Buffer.from([0]),
    Buffer.from(Array.from({ length: width * bytesPerPixel }, () => 128)),
  ]);
  const raw = Buffer.concat(Array.from({ length: height }, () => row));

  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk("IHDR", head),
    chunk("IDAT", deflateSync(raw)),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

function makeJpeg(width = 64, height = 64): Buffer {
  // Minimal valid JPEG with SOF0 marker
  const header = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00]);
  const sof = Buffer.alloc(17);
  sof[0] = 0xff;
  sof[1] = 0xc0; // SOF0
  sof.writeUInt16BE(15, 2); // length
  sof[4] = 8; // precision
  sof.writeUInt16BE(height, 5); // height
  sof.writeUInt16BE(width, 7); // width
  sof[9] = 3; // components
  const footer = Buffer.from([0xff, 0xd9]);
  return Buffer.concat([header, sof, footer]);
}

function makeWebp(width = 64, height = 64): Buffer {
  const data = Buffer.alloc(32);
  data.write("RIFF", 0);
  data.writeUInt32LE(24, 4);
  data.write("WEBP", 8);
  data.write("VP8X", 12);
  data.writeUInt32LE(10, 16);
  data[20] = 0x10; // hasAlpha flag
  data.writeUIntLE(width - 1, 24, 3);
  data.writeUIntLE(height - 1, 27, 3);
  return data;
}

function makeSvg(width = 120, height = 80): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><circle cx="20" cy="20" r="10"/></svg>`;
}

function makeJsonAnimation(): string {
  return JSON.stringify({
    v: "5.5.7",
    fr: 60,
    ip: 0,
    op: 120,
    w: 500,
    h: 500,
    layers: [],
  });
}

function dataUrl(mime: string, buffer: Buffer | string): string {
  const base64 = typeof buffer === "string" ? Buffer.from(buffer).toString("base64") : buffer.toString("base64");
  return `data:${mime};base64,${base64}`;
}

const baseBlueprint = (): GameBlueprint =>
  draftToBlueprint(
    { ...createDefaultDraft(), title: "Asset Test", theme: "Roman Empire" },
    { id: "asset-test-project", now: NOW },
  );

/* --------------------------- Format Decoding & Validation --------------------------- */

test("decodeArtwork decodes Transparent PNG and detects alpha channel", () => {
  const transparentPng = makePng(6, 120, 80);
  const uri = dataUrl("image/png", transparentPng);
  const decoded = decodeArtwork(uri, "symbol-alpha.png");

  assert.equal(decoded.format, "png-transparent");
  assert.equal(decoded.hasAlpha, true);
  assert.equal(decoded.width, 120);
  assert.equal(decoded.height, 80);
  assert.equal(decoded.kind, "image");
});

test("decodeArtwork decodes standard opaque PNG", () => {
  const opaquePng = makePng(2, 60, 40);
  const uri = dataUrl("image/png", opaquePng);
  const decoded = decodeArtwork(uri, "opaque.png");

  assert.equal(decoded.format, "png");
  assert.equal(decoded.hasAlpha, false);
  assert.equal(decoded.width, 60);
  assert.equal(decoded.height, 40);
});

test("decodeArtwork decodes JPEG and extracts dimensions", () => {
  const jpegBuf = makeJpeg(320, 240);
  const uri = dataUrl("image/jpeg", jpegBuf);
  const decoded = decodeArtwork(uri, "background.jpg");

  assert.equal(decoded.format, "jpeg");
  assert.equal(decoded.hasAlpha, false);
  assert.equal(decoded.width, 320);
  assert.equal(decoded.height, 240);
});

test("decodeArtwork decodes WebP with dimensions and alpha", () => {
  const webpBuf = makeWebp(200, 150);
  const uri = dataUrl("image/webp", webpBuf);
  const decoded = decodeArtwork(uri, "icon.webp");

  assert.equal(decoded.format, "webp");
  assert.equal(decoded.hasAlpha, true);
  assert.equal(decoded.width, 200);
  assert.equal(decoded.height, 150);
});

test("decodeArtwork decodes Vector SVG and extracts viewBox dimensions", () => {
  const svgText = makeSvg(400, 300);
  const uri = dataUrl("image/svg+xml", svgText);
  const decoded = decodeArtwork(uri, "frame.svg");

  assert.equal(decoded.format, "svg");
  assert.equal(decoded.hasAlpha, true);
  assert.equal(decoded.width, 400);
  assert.equal(decoded.height, 300);
  assert.equal(decoded.kind, "image");
});

test("decodeArtwork decodes Animation JSON metadata (Spine/Lottie)", () => {
  const jsonText = makeJsonAnimation();
  const uri = dataUrl("application/json", jsonText);
  const decoded = decodeArtwork(uri, "spin_anim.json");

  assert.equal(decoded.format, "json-animation");
  assert.equal(decoded.kind, "spine");
  assert.equal(decoded.width, 500);
  assert.equal(decoded.height, 500);
});

test("decodeArtwork rejects HTML, script tags, or corrupt binary", () => {
  const htmlUri = dataUrl("text/html", "<h1>Not allowed</h1>");
  assert.throws(() => decodeArtwork(htmlUri, "danger.html"));

  const badSvg = dataUrl("image/svg+xml", "<svg><script>alert(1)</script></svg>");
  assert.throws(() => decodeArtwork(badSvg, "danger.svg"));

  const fakePng = dataUrl("image/png", Buffer.from("not a real png"));
  assert.throws(() => decodeArtwork(fakePng, "fake.png"));
});

test("detectAssetFormat identifies formats correctly from AssetRef", () => {
  const a1: AssetRef = { id: "1", name: "test.png", kind: "image", uri: "/test.png", state: "linked", tags: [], format: "png-transparent" };
  assert.equal(detectAssetFormat(a1).format, "png-transparent");
  assert.equal(detectAssetFormat(a1).isTransparent, true);

  const a2: AssetRef = { id: "2", name: "art.svg", kind: "image", uri: "/art.svg", state: "linked", tags: [] };
  assert.equal(detectAssetFormat(a2).format, "svg");
  assert.equal(detectAssetFormat(a2).isTransparent, true);

  const a3: AssetRef = { id: "3", name: "anim.json", kind: "spine", uri: "/anim.json", state: "linked", tags: [] };
  assert.equal(detectAssetFormat(a3).format, "json-animation");

  const a4: AssetRef = { id: "4", name: "photo.jpg", kind: "image", uri: "/photo.jpg", state: "linked", tags: [] };
  assert.equal(detectAssetFormat(a4).format, "jpeg");
});

/* --------------------------- Usage Tracking & Safe Deletion --------------------------- */

test("findAssetUsage detects references in symbols, elements, scenes, canvas and style", () => {
  const bp = baseBlueprint();
  const assetId = "shared-asset-1";
  const asset: AssetRef = { id: assetId, name: "shared.png", kind: "image", uri: "/api/assets/shared", state: "linked", tags: [] };
  bp.assets.push(asset);

  // Link asset to symbol, element, canvas background, and scene
  bp.symbols[0].assetId = assetId;
  bp.elements[0].assetId = assetId;
  bp.canvas.backgroundAssetId = assetId;
  bp.scenes[0].background = { color: "#000", assetId };

  const usages = findAssetUsage(bp, assetId);
  assert.ok(usages.length >= 4, "detected all 4 usages");

  const categories = usages.map((u) => u.category);
  assert.ok(categories.includes("symbol"));
  assert.ok(categories.includes("element"));
  assert.ok(categories.includes("canvas_background"));
  assert.ok(categories.includes("scene_background"));
});

test("safeUnbindAsset cleanly unbinds all references without corrupting blueprint integrity", () => {
  const bp = baseBlueprint();
  const assetId = "doomed-asset";
  const asset: AssetRef = { id: assetId, name: "doomed.png", kind: "image", uri: "/api/assets/doomed", state: "linked", tags: [] };
  bp.assets.push(asset);

  bp.symbols[0].assetId = assetId;
  bp.symbols[0].image = { provider: "project", assetId };
  bp.elements[0].assetId = assetId;
  bp.elements[0].image = { provider: "project", assetId };
  bp.canvas.backgroundAssetId = assetId;
  bp.scenes[0].background = { color: null, assetId };

  // Deletion with safe unbind
  const cleaned = safeUnbindAsset(bp, assetId);

  // Asset is removed from assets list
  assert.equal(cleaned.assets.some((a) => a.id === assetId), false);

  // All references are reset to null/placeholder
  assert.equal(cleaned.symbols[0].assetId, null);
  assert.equal(cleaned.symbols[0].image, null);
  assert.equal(cleaned.elements[0].assetId, null);
  assert.equal(cleaned.elements[0].image, null);
  assert.equal(cleaned.canvas.backgroundAssetId, null);
  assert.equal(cleaned.scenes[0].background?.assetId, null);

  // Blueprint integrity must be 100% valid
  const validation = validateBlueprint(cleaned);
  assert.equal(validation.integrityOk, true, `Blueprint integrity issues: ${validation.integrityIssues.join(", ")}`);
});

test("assignAsset assigns asset to symbol, element, scene and canvas background", () => {
  const bp = baseBlueprint();
  const assetId = "assigned-asset";
  const asset: AssetRef = { id: assetId, name: "gold-coin.png", kind: "image", uri: "/api/assets/coin", state: "linked", tags: [] };
  bp.assets.push(asset);

  // Assign to symbol
  const symTarget = bp.symbols[0].id;
  const bpWithSym = assignAsset(bp, assetId, { type: "symbol", targetId: symTarget });
  assert.equal(bpWithSym.symbols.find((s) => s.id === symTarget)?.assetId, assetId);
  assert.equal(bpWithSym.symbols.find((s) => s.id === symTarget)?.image?.assetId, assetId);

  // Assign to canvas background
  const bpWithCanvas = assignAsset(bp, assetId, { type: "canvas_background", targetId: "" });
  assert.equal(bpWithCanvas.canvas.backgroundAssetId, assetId);

  // Assign to scene background
  const sceneId = bp.scenes[0].id;
  const bpWithScene = assignAsset(bp, assetId, { type: "scene_background", targetId: sceneId });
  assert.equal(bpWithScene.scenes.find((sc) => sc.id === sceneId)?.background?.assetId, assetId);

  const check = validateBlueprint(bpWithSym);
  assert.equal(check.integrityOk, true);
});
