import { deriveElements } from "@/lib/blueprint/elements";
import { ROYAL_CODES, defaultSymbolStats } from "@/lib/blueprint/factory";
import type { ElementDef, GameBlueprint, SymbolDef } from "@/lib/blueprint/types";
import { SET_TYPE_LABELS, finalizeDoc, uniqueCode, uniqueId, valueOfTier } from "./model";
import type { DesignDoc } from "./types";

/** Assets used by scene layout, which the design editor must never prune. */
export function sceneAssetIds(bp: GameBlueprint): string[] {
  const ids: string[] = [];
  for (const scene of bp.scenes ?? []) {
    if (scene.background?.assetId) ids.push(scene.background.assetId);
    for (const object of scene.objects ?? []) if (object.assetId) ids.push(object.assetId);
  }
  return Array.from(new Set(ids));
}

export function designDocFromBlueprint(bp: GameBlueprint): DesignDoc {
  return {
    elements: bp.elements ?? deriveElements(bp),
    symbols: bp.symbols,
    specialSymbols: bp.specialSymbols,
    assets: bp.assets,
    paytable: bp.paytable,
    strips: bp.reels.strips,
    referenceAssetId: bp.style.referenceAssetId ?? null,
    protectedAssetIds: sceneAssetIds(bp),
  };
}

/** Writes the design slice back into a blueprint, deriving symbolSets and the canvas background. */
export function applyDesign(bp: GameBlueprint, doc: DesignDoc): GameBlueprint {
  const backgrounds = doc.elements.filter((e) => e.type === "game_background");
  const linked = backgrounds.find((e) => e.assetId && doc.assets.some((a) => a.id === e.assetId && a.state === "linked"));
  const background = linked?.assetId ?? backgrounds[0]?.assetId ?? null;
  return {
    ...bp,
    elements: doc.elements,
    symbols: doc.symbols,
    symbolSets: doc.elements
      .filter((e) => e.type === "symbol_set")
      .map((e) => ({
        id: e.id,
        name: e.name,
        description: e.symbolSet?.description ?? e.notes,
        symbolIds: e.symbolIds,
        symbolType: e.symbolSet?.symbolType ?? "custom",
        valueTier: e.symbolSet?.valueTier ?? "medium",
        frame: e.symbolSet?.frame ?? null,
        background: e.symbolSet?.background ?? null,
        styleGuide: e.symbolSet?.styleGuide ?? "",
        tags: [...(e.symbolSet?.tags ?? [])],
      })),
    specialSymbols: doc.specialSymbols,
    assets: doc.assets,
    paytable: doc.paytable,
    reels: { ...bp.reels, strips: doc.strips },
    canvas: { ...bp.canvas, backgroundAssetId: background },
    exportConfig: { ...bp.exportConfig, includeAssets: doc.assets.some((a) => a.state === "linked") },
  };
}

const TIER_NAMES = { low: "Low", mid: "Medium", high: "High" } as const;

/**
 * Upgrades blueprints created before F04 (idempotent, deterministic):
 *  - sets gain a symbol type + value tier; mixed medium/high sets are split by tier
 *  - special symbols live as standalone symbols, never inside a set
 *  - imported symbol artwork that had no symbol becomes a real symbol
 *  - symbols nobody owns are adopted into sets so they stay visible
 */
export function migrateDoc(input: DesignDoc): DesignDoc {
  const symbols = [...input.symbols];
  const byId = new Map(symbols.map((s) => [s.id, s]));
  const elementIds = new Set(input.elements.map((e) => e.id));
  const symbolIds = new Set(symbols.map((s) => s.id));
  const codes = new Set(symbols.map((s) => s.code));
  const standaloneOwned = new Set(input.elements.filter((e) => e.type === "symbol").flatMap((e) => e.symbolIds));

  const artSymbol = (name: string, assetId: string): SymbolDef => {
    const symbol: SymbolDef = {
      id: uniqueId("sym-mid", symbolIds),
      code: uniqueCode("M", codes),
      name,
      tier: "mid",
      glyph: "◆",
      assetId,
      ...defaultSymbolStats("mid", symbols.filter((s) => s.tier === "mid").length),
    };
    symbols.push(symbol);
    byId.set(symbol.id, symbol);
    return symbol;
  };
  const isRoyals = (group: SymbolDef[]) => group.length > 0 && group.every((s) => ROYAL_CODES.includes(s.code));
  const setFor = (base: ElementDef, id: string, name: string, group: SymbolDef[], tier: SymbolDef["tier"]): ElementDef => {
    const royals = isRoyals(group);
    return {
      ...base,
      id,
      name,
      group: royals ? SET_TYPE_LABELS.royals : SET_TYPE_LABELS.custom,
      symbolIds: group.map((s) => s.id),
      assetId: null,
      symbolSet: { symbolType: royals ? "royals" : "custom", valueTier: valueOfTier(tier) },
    };
  };

  const out: ElementDef[] = [];
  for (const el of input.elements) {
    if (el.type === "symbol" && el.symbolIds.length === 0 && el.assetId) {
      out.push({ ...el, symbolIds: [artSymbol(el.name, el.assetId).id], assetId: null });
      continue;
    }
    if (el.type !== "symbol_set" || el.symbolSet) {
      out.push(el);
      continue;
    }
    const members = el.symbolIds.map((id) => byId.get(id)).filter((s): s is SymbolDef => Boolean(s));
    if (members.length === 0) {
      const art = el.assetId ? [artSymbol(el.name, el.assetId)] : [];
      out.push({ ...el, assetId: null, symbolIds: art.map((s) => s.id), symbolSet: { symbolType: "custom", valueTier: "medium" } });
      continue;
    }
    const regular = members.filter((s) => s.tier !== "special" && !standaloneOwned.has(s.id));
    const tiers = (["low", "mid", "high"] as const).filter((t) => regular.some((s) => s.tier === t));
    tiers.forEach((tier) => {
      const group = regular.filter((s) => s.tier === tier);
      out.push(
        tiers.length === 1
          ? setFor(el, el.id, el.name, group, tier)
          : setFor(el, uniqueId(el.id, elementIds), `${TIER_NAMES[tier]} Symbols`, group, tier),
      );
    });
  }

  const owned = new Set(out.flatMap((e) => e.symbolIds));
  const orphans = symbols.filter((s) => !owned.has(s.id));
  for (const symbol of orphans.filter((s) => s.tier === "special")) {
    out.push({
      id: uniqueId("el-special", elementIds),
      type: "symbol",
      name: symbol.name,
      group: "Special",
      assetId: null,
      symbolIds: [symbol.id],
      notes: "",
      origin: "planned",
      params: {},
    });
  }
  for (const tier of ["low", "mid", "high"] as const) {
    const group = orphans.filter((s) => s.tier === tier);
    if (group.length === 0) continue;
    out.push(setFor(
      { id: "", type: "symbol_set", name: "", group: "", assetId: null, symbolIds: [], notes: "", origin: "planned", params: {} },
      uniqueId("el-symbol-set", elementIds),
      `${TIER_NAMES[tier]} Symbols`,
      group,
      tier,
    ));
  }

  return finalizeDoc({ ...input, elements: out, symbols });
}

/** Normalises any stored blueprint to the current Design model. */
export function migrateBlueprint(bp: GameBlueprint): GameBlueprint {
  return applyDesign(bp, migrateDoc(designDocFromBlueprint(bp)));
}
