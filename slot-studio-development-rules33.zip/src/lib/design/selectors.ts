import type { AssetRef, ElementDef, ElementType, SymbolDef } from "@/lib/blueprint/types";
import { isLinked } from "./model";
import type { DesignDoc } from "./types";

export type StatusKey = "empty" | "planned" | "partial" | "ready";
export interface StatusInfo {
  key: StatusKey;
  label: string;
  detail: string;
}
export interface SetView {
  element: ElementDef;
  symbols: SymbolDef[];
  withArt: number;
  status: StatusInfo;
}

export const assetOf = (doc: DesignDoc, id: string | null): AssetRef | null =>
  id ? (doc.assets.find((a) => a.id === id) ?? null) : null;

export function symbolImage(doc: DesignDoc, symbol: SymbolDef) {
  const asset = assetOf(doc, symbol.assetId);
  return isLinked(asset) ? asset : null;
}

/** The single image an element shows. Sets have none (they show their members). */
export function elementImage(doc: DesignDoc, element: ElementDef) {
  if (element.type === "symbol_set") return null;
  if (element.type === "symbol") {
    const symbol = doc.symbols.find((s) => s.id === element.symbolIds[0]);
    return symbol ? symbolImage(doc, symbol) : null;
  }
  const asset = assetOf(doc, element.assetId);
  return isLinked(asset) ? asset : null;
}

export function setStatus(withArt: number, total: number): StatusInfo {
  if (total === 0) return { key: "empty", label: "Empty", detail: "No symbols yet" };
  if (withArt === 0) return { key: "planned", label: "Planned", detail: "No artwork linked" };
  if (withArt < total) return { key: "partial", label: "Partial", detail: `${withArt} of ${total} have artwork` };
  return { key: "ready", label: "Ready", detail: "All symbols have artwork" };
}

export function standaloneStatus(doc: DesignDoc, element: ElementDef): StatusInfo {
  return elementImage(doc, element)
    ? { key: "ready", label: "Ready", detail: "Artwork linked" }
    : { key: "planned", label: "Planned", detail: "No artwork linked" };
}

export function elementStatus(doc: DesignDoc, element: ElementDef): StatusInfo {
  if (element.type !== "symbol_set") return standaloneStatus(doc, element);
  const symbols = membersOf(doc, element);
  return setStatus(symbols.filter((s) => symbolImage(doc, s)).length, symbols.length);
}

export function membersOf(doc: DesignDoc, element: ElementDef): SymbolDef[] {
  const byId = new Map(doc.symbols.map((s) => [s.id, s]));
  return element.symbolIds.map((id) => byId.get(id)).filter((s): s is SymbolDef => Boolean(s));
}

export function selectSets(doc: DesignDoc): SetView[] {
  return doc.elements
    .filter((e) => e.type === "symbol_set")
    .map((element) => {
      const symbols = membersOf(doc, element);
      const withArt = symbols.filter((s) => symbolImage(doc, s)).length;
      return { element, symbols, withArt, status: setStatus(withArt, symbols.length) };
    });
}

export const selectStandalone = (doc: DesignDoc): ElementDef[] => doc.elements.filter((e) => e.type !== "symbol_set");
export const findElement = (doc: DesignDoc, id: string | null | undefined) =>
  id ? (doc.elements.find((e) => e.id === id) ?? null) : null;

export function findSymbol(doc: DesignDoc, id: string) {
  const symbol = doc.symbols.find((s) => s.id === id);
  if (!symbol) return null;
  return { symbol, owner: doc.elements.find((e) => e.symbolIds.includes(id)) ?? null };
}

export function matchesQuery(query: string, ...parts: string[]): boolean {
  const q = query.trim().toLowerCase();
  if (!q) return true;
  const hay = parts.join(" ").toLowerCase();
  return q.split(/\s+/).every((term) => hay.includes(term));
}

export type StandaloneFilter = "all" | Exclude<ElementType, "symbol_set">;
export const STANDALONE_FILTERS: { id: StandaloneFilter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "symbol", label: "Symbols" },
  { id: "game_title", label: "Title" },
  { id: "game_background", label: "Backgrounds" },
  { id: "reel_frame", label: "Frames" },
  { id: "button_set", label: "Buttons" },
  { id: "uploaded", label: "Uploaded" },
  { id: "custom", label: "Custom" },
  { id: "other_asset", label: "Other" },
];
