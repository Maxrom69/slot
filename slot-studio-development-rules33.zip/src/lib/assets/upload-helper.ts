import type { AssetFormat } from "@/lib/blueprint/types";

export const MAX_UPLOAD_SOURCE_BYTES = 15 * 1024 * 1024; // 15 MB
export const MAX_IMAGE_DIMENSION = 20000;

export interface ValidatedUpload {
  name: string;
  dataUrl: string;
  mime: string;
  sizeBytes: number;
  width: number | null;
  height: number | null;
  format: AssetFormat;
}

export class AssetValidationError extends Error {}

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new AssetValidationError(`Could not read “${file.name}”.`));
    reader.readAsDataURL(file);
  });
}

function measureImage(dataUrl: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight });
    img.onerror = () => reject(new AssetValidationError("The file could not be decoded as a valid image."));
    img.src = dataUrl;
  });
}

/**
 * Validates file type, file size, and image dimensions.
 * Supports Transparent PNG, JPEG, WebP, Vector SVG, Animation JSON, and Audio.
 */
export async function validateAndPrepareUpload(file: File): Promise<ValidatedUpload> {
  if (file.size > MAX_UPLOAD_SOURCE_BYTES) {
    throw new AssetValidationError(`“${file.name}” is too large (${(file.size / 1024 / 1024).toFixed(1)} MB). Maximum allowed size is 15 MB.`);
  }

  const name = file.name.trim();
  const lowerName = name.toLowerCase();
  const rawMime = file.type.toLowerCase();

  // 1. Vector (SVG)
  if (rawMime === "image/svg+xml" || lowerName.endsWith(".svg")) {
    const dataUrl = await readAsDataUrl(file);
    let dims = { width: 512, height: 512 };
    try {
      dims = await measureImage(dataUrl);
    } catch {
      // fallback for SVG without explicit pixel sizing
    }
    return {
      name,
      dataUrl,
      mime: "image/svg+xml",
      sizeBytes: file.size,
      width: dims.width || 512,
      height: dims.height || 512,
      format: "svg",
    };
  }

  // 2. Animation JSON / Spine / Lottie
  if (rawMime === "application/json" || lowerName.endsWith(".json")) {
    const text = await file.text();
    try {
      const obj = JSON.parse(text);
      if (!obj || typeof obj !== "object") throw new Error();
      const base64 = btoa(unescape(encodeURIComponent(text)));
      const dataUrl = `data:application/json;base64,${base64}`;
      const width = typeof obj.w === "number" ? Math.round(obj.w) : null;
      const height = typeof obj.h === "number" ? Math.round(obj.h) : null;
      return {
        name,
        dataUrl,
        mime: "application/json",
        sizeBytes: file.size,
        width,
        height,
        format: "json-animation",
      };
    } catch {
      throw new AssetValidationError(`“${name}” is not valid animation JSON metadata.`);
    }
  }

  // 3. Audio
  if (rawMime.startsWith("audio/") || lowerName.match(/\.(mp3|wav|ogg|aac)$/)) {
    const mime = rawMime || (lowerName.endsWith(".wav") ? "audio/wav" : lowerName.endsWith(".ogg") ? "audio/ogg" : "audio/mpeg");
    const dataUrl = await readAsDataUrl(file);
    return {
      name,
      dataUrl,
      mime,
      sizeBytes: file.size,
      width: null,
      height: null,
      format: "audio",
    };
  }

  // 4. Raster Images: PNG, JPEG, WebP
  const isPng = rawMime === "image/png" || lowerName.endsWith(".png");
  const isJpeg = rawMime === "image/jpeg" || rawMime === "image/jpg" || lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg");
  const isWebp = rawMime === "image/webp" || lowerName.endsWith(".webp");

  if (!isPng && !isJpeg && !isWebp) {
    throw new AssetValidationError(`“${name}” is not an accepted asset type. Supported: PNG, JPEG, WebP, SVG Vector, Animation JSON, and Audio.`);
  }

  const mime = isPng ? "image/png" : isJpeg ? "image/jpeg" : "image/webp";
  const dataUrl = await readAsDataUrl(file);

  const dims = await measureImage(dataUrl);
  if (!dims.width || !dims.height || dims.width <= 0 || dims.height <= 0) {
    throw new AssetValidationError(`“${name}” has invalid image dimensions (${dims.width} × ${dims.height}).`);
  }
  if (dims.width > MAX_IMAGE_DIMENSION || dims.height > MAX_IMAGE_DIMENSION) {
    throw new AssetValidationError(`“${name}” dimensions (${dims.width} × ${dims.height}) exceed maximum allowed (${MAX_IMAGE_DIMENSION} × ${MAX_IMAGE_DIMENSION}).`);
  }

  const format: AssetFormat = isPng ? "png-transparent" : isJpeg ? "jpeg" : "webp";

  return {
    name,
    dataUrl,
    mime,
    sizeBytes: file.size,
    width: dims.width,
    height: dims.height,
    format,
  };
}
