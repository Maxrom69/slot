/**
 * Lossless mapping between the Game Blueprint storage form and the F07
 * ElementLibrary domain model. Legacy fields (glyph, code, payouts,
 * reelWeight, params, assetId) are preserved on both sides so existing
 * projects round-trip unchanged.
 */

import type {
  AssetReference,
  ElementDef,
  GameBlueprint,
  SymbolDef,
  SymbolSetType,
  ValueTier,
} from "@/lib/blueprint/types";
import { projectAssetIdOf } from "./assets";
import { canonicalSymbolType, type ElementLibrary, type StandaloneElement, type Symbol, type SymbolType } from "./types";
import { SYMBOL_TYPE_TO_STORED } from "./types";

const LEGACY_SET_TYPE: Record<string, SymbolSetType> = {
  character: "character",
  royals: "royals",
  suits: "suits",
  seven: "seven",
  bar: "bar",
  custom: "custom",
};

function storedSetType(symbolType: SymbolType): SymbolSetType {
  return SYMBOL_TYPE_TO_STORED[symbolType] ?? "custom";
}

function imageFromAssetId(assetId: string | null): AssetReference | null {
  if (!assetId) return null;
  return { provider: "project", assetId };
}

function symbolFromDef(
  def: SymbolDef,
  ownerSetId: string | null,
  elementBySymbol: Map<string, ElementDef>,
): Symbol {
  const owner = elementBySymbol.get(def.id);
  const setType = (owner?.symbolSet?.symbolType ?? def.symbolType ?? "custom") as SymbolSetType;
  return {
    id: def.id,
    name: def.name,
    symbolSetId: ownerSetId,
    symbolType: canonicalSymbolType(LEGACY_SET_TYPE[setType] ?? "custom"),
    tier: def.tier === "mid" ? "medium" : def.tier === "low" ? "low" : def.tier === "high" ? "high" : "special",
    image: def.image ?? imageFromAssetId(def.assetId),
    variants: (def.variants ?? []).map((v) => ({
      id: v.id,
      name: v.name,
      image: v.image ?? null,
      extras: { ...(v.extras ?? {}) },
      tags: [...(v.tags ?? [])],
    })),
    extras: { ...(def.extras ?? {}) },
    mathId: def.mathId ?? null,
    isWild: def.isWild ?? def.tier === "special",
    isScatter: def.isScatter ?? false,
    code: def.code,
    glyph: def.glyph,
    reelWeight: def.reelWeight,
    payouts: { ...def.payouts },
    description: def.description ?? "",
    tags: [...(def.tags ?? [])],
  };
}

function standaloneFromDef(def: ElementDef): StandaloneElement | null {
  const base = {
    id: def.id,
    name: def.name,
    description: def.notes ?? "",
    tags: [],
    image: def.image ?? imageFromAssetId(def.assetId),
  };
  switch (def.type) {
    case "game_title":
      return { ...base, kind: "game-title" as const };
    case "game_background":
      return { ...base, kind: "game-background" as const, aspect: String(def.params.aspect ?? "16:9") };
    case "reel_frame":
      return { ...base, kind: "reel-frame" as const, style: String(def.params.style ?? "Themed") };
    case "button_set": {
      const buttons = String(def.params.buttons ?? "spin").split(",").filter(Boolean);
      return { ...base, kind: "button-set" as const, buttons: buttons.length ? buttons : ["spin"] };
    }
    case "uploaded":
    case "other_asset":
      return { ...base, kind: "uploaded" as const, group: def.group || "Uploaded art" };
    case "custom":
      return { ...base, kind: "custom" as const, group: def.group || "Other", params: { ...def.params } };
    default:
      return null;
  }
}

/** Blueprint storage -> canonical library. Never throws; unknown shapes are skipped. */
export function libraryFromBlueprint(bp: Pick<GameBlueprint, "elements" | "symbols">): ElementLibrary {
  const elementBySymbol = new Map<string, ElementDef>();
  for (const el of bp.elements ?? []) {
    if (el.type === "symbol_set" || el.type === "symbol") {
      for (const sid of el.symbolIds) if (!elementBySymbol.has(sid)) elementBySymbol.set(sid, el);
    }
  }
  const sets = (bp.elements ?? [])
    .filter((el) => el.type === "symbol_set")
    .map((el) => ({
      id: el.id,
      kind: "symbol-set" as const,
      name: el.name,
      description: el.notes ?? "",
      tags: [] as string[],
      image: null,
      symbolType: canonicalSymbolType((el.symbolSet?.symbolType ?? "custom") as SymbolSetType),
      valueTier: ((el.symbolSet?.valueTier ?? "medium") === "special" ? "medium" : (el.symbolSet?.valueTier ?? "medium")) as Exclude<ValueTier, "special">,
      frame: el.symbolSet?.frame ?? null,
      background: el.symbolSet?.background ?? null,
      symbols: [...el.symbolIds],
      styleGuide: el.symbolSet?.styleGuide ?? "",
    }));
  const setIds = new Map<string, string>();
  for (const el of bp.elements ?? []) {
    if (el.type !== "symbol_set") continue;
    for (const sid of el.symbolIds) if (!setIds.has(sid)) setIds.set(sid, el.id);
  }
  const symbols = (bp.symbols ?? []).map((s) => symbolFromDef(s, setIds.get(s.id) ?? null, elementBySymbol));
  const standalone = (bp.elements ?? [])
    .map(standaloneFromDef)
    .filter((s): s is StandaloneElement => s !== null);
  return { sets, symbols, standalone };
}

/** Writes library state back onto blueprint symbol/element defs, preserving legacy fields. */
export function applyLibraryToSymbols(
  symbols: SymbolDef[],
  lib: ElementLibrary,
): SymbolDef[] {
  const byId = new Map(lib.symbols.map((s) => [s.id, s]));
  return symbols.map((def) => {
    const s = byId.get(def.id);
    if (!s) return def;
    return {
      ...def,
      name: s.name,
      symbolSetId: s.symbolSetId,
      symbolType: storedSetType(s.symbolType),
      image: s.image,
      assetId: projectAssetIdOf(s.image) ?? s.image?.provider === "project" ? (projectAssetIdOf(s.image) ?? def.assetId) : def.assetId,
      variants: s.variants.map((v) => ({ id: v.id, name: v.name, image: v.image, extras: { ...v.extras }, tags: [...(v.tags ?? [])] })),
      extras: { ...s.extras },
      mathId: s.mathId,
      isWild: s.isWild,
      isScatter: s.isScatter,
      description: s.description,
      tags: [...s.tags],
    };
  });
}
