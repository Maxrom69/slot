/**
 * SECTION 1 — FRONTEND / SLOTS STUDIO BUILDER
 * Game Blueprint typed model.
 *
 * The Game Blueprint is the single source of truth of the studio.
 * It is purely declarative data: no rendering, no engine logic.
 * SECTION 2 (backend slot engine) will consume this structure.
 */

export const BLUEPRINT_VERSION = 1 as const;

export type ProjectStatus =
  | "draft"
  | "blueprint"
  | "math"
  | "prototype"
  | "team_review"
  | "released";

export type Volatility = "low" | "medium" | "high" | "extreme";

export interface ProjectMeta {
  id: string;
  title: string;
  slug: string;
  description: string;
  status: ProjectStatus;
  theme: string;
  styleGuide: string;
  tags: string[];
  studio: string;
  createdAt: string;
  updatedAt: string;
  schemaVersion: number;
  /** Organisation is included in exports, not just in the dashboard index. */
  folderPath?: string;
}

export interface StylePalette {
  background: string;
  surface: string;
  accent: string;
  accentAlt: string;
  glow: string;
  text: string;
}

export interface ThemeStyle {
  paletteName: string;
  palette: StylePalette;
  mood: string;
  artDirection: string;
  typography: { display: string; body: string };
  /** optional reference artwork (asset id) supplied at creation */
  referenceAssetId?: string | null;
}

export type SymbolTier = "low" | "mid" | "high" | "special";

/** Documented symbol set categories and the value tier a set is designed for.
 * Canonical F07 conceptual types: Characters (character), Deck Ranks (royals),
 * Suits (suits), Custom (custom). `seven` and `bar` are legacy classic types
 * kept for backward compatibility with existing blueprints. */
export type SymbolSetType = "character" | "royals" | "suits" | "seven" | "bar" | "custom";
/** Canonical symbol-type names used by the F07 element system. */
export type CanonicalSymbolType = "characters" | "ranks" | "suits" | "custom";
export type ValueTier = "low" | "medium" | "high" | "special";
export interface SymbolSetMeta {
  symbolType: SymbolSetType;
  valueTier: ValueTier;
  /** Optional frame element or asset referenced by this set. */
  frame?: AssetReference | null;
  /** Optional background element or asset referenced by this set. */
  background?: AssetReference | null;
  styleGuide?: string;
  description?: string;
  tags?: string[];
}

/**
 * Storage-agnostic image reference. The studio never binds itself to one
 * provider: `project` resolves through the project's own asset store,
 * `external` is a plain URL, and `placeholder` renders a deterministic stand-in.
 */
export interface AssetReference {
  provider: "project" | "external" | "placeholder";
  /** project asset id when provider is `project`. */
  assetId?: string | null;
  /** direct URL when provider is `external`. */
  uri?: string | null;
  /** human label, never used as an identifier. */
  name?: string;
}

/** A custom variant of a symbol. Always carries its own stable id. */
export interface SymbolVariant {
  id: string;
  name: string;
  image: AssetReference | null;
  extras: Record<string, number | string | boolean>;
  tags?: string[];
}

/** One recorded version of a symbol's image. Older revisions stay addressable forever. */
export interface ImageRevision {
  id: string;
  /** Storage-agnostic reference to that version's image. */
  asset: AssetReference | null;
  createdAt: string;
  /** How this version came to be. */
  source: "create" | "import" | "upload" | "duplicate" | "variant" | "restore";
  notes?: string;
}

/** Extensible free-form extra metadata. Not evaluated by the studio. */
export interface SymbolExtra {
  key: string;
  value: number | string | boolean;
}

export interface SymbolDef {
  id: string;
  code: string;
  name: string;
  tier: SymbolTier;
  glyph: string;
  assetId: string | null;
  /** payout multiplier keyed by "of a kind" count */
  payouts: Record<string, number>;
  reelWeight: number;
  /** Owning symbol set element id. Null for standalone symbols. */
  symbolSetId?: string | null;
  /** Conceptual symbol type (characters / ranks / suits / custom + legacy). */
  symbolType?: SymbolSetType;
  /** Symbol family groups. */
  family?: string;
  /** Storage-agnostic image reference. Mirrors assetId for project assets. */
  image?: AssetReference | null;
  /** Recorded image versions on this symbol, newest first. */
  imageHistory?: ImageRevision[];
  /** Independent custom variants, each with its own stable id. */
  variants?: SymbolVariant[];
  /** Free-form custom data. Never evaluated by the studio. */
  extras?: Record<string, number | string | boolean>;
  /** Opaque gameplay identifier consumed only by the SECTION 2 engine. */
  mathId?: string | null;
  /** Gameplay flags kept strictly as configuration. No payout evaluation here. */
  isWild?: boolean;
  isScatter?: boolean;
  isBonus?: boolean;
  description?: string;
  tags?: string[];
}

export interface SymbolSetDef {
  id: string;
  name: string;
  description: string;
  symbolIds: string[];
  symbolType?: SymbolSetType;
  valueTier?: ValueTier;
  /** Optional frame reference for the set presentation. */
  frame?: AssetReference | null;
  /** Optional background reference for the set presentation. */
  background?: AssetReference | null;
  styleGuide?: string;
  tags?: string[];
}

export type SpecialBehaviour =
  | "wild"
  | "scatter"
  | "bonus"
  | "multiplier"
  | "expanding"
  | "sticky";

export interface SpecialSymbolDef {
  id: string;
  symbolId: string;
  behaviour: SpecialBehaviour;
  params: Record<string, number | string | boolean>;
}

export type AssetKind = "image" | "sprite" | "spine" | "audio" | "font";

export type AssetFormat =
  | "png"
  | "png-transparent"
  | "jpeg"
  | "webp"
  | "svg"
  | "json-animation"
  | "audio"
  | "other";

export interface AssetRevision {
  id: string;
  uri: string;
  createdAt: string;
  source?: string;
  notes?: string;
}

export interface AssetRef {
  id: string;
  name: string;
  kind: AssetKind;
  uri: string | null;
  /** placeholder = no binary bound yet (studio is art-tool agnostic) */
  state: "placeholder" | "linked";
  tags: string[];
  width?: number | null;
  height?: number | null;
  format?: AssetFormat;
  mime?: string;
  sizeBytes?: number;
  hasAlpha?: boolean;
  createdAt?: string;
  updatedAt?: string;
  revisions?: AssetRevision[];
}

/**
 * Creation / design element categories. These mirror the documented element
 * categories of the studio and are the unit shown in the Design workspace.
 */
export type ElementType =
  | "symbol_set"
  | "symbol"
  | "game_title"
  | "reel_frame"
  | "game_background"
  | "button_set"
  | "uploaded"
  | "custom"
  | "other_asset";

export interface ElementDef {
  id: string;
  type: ElementType;
  name: string;
  /** free-form grouping label shown as a badge ("Royals", "Branding"…) */
  group: string;
  assetId: string | null;
  symbolIds: string[];
  notes: string;
  /** planned = structure only; imported = bound to user artwork */
  origin: "planned" | "imported";
  params: Record<string, number | string | boolean>;
  /** Present on symbol_set elements: symbolIds are the set members. */
  symbolSet?: SymbolSetMeta;
  /** Editable standalone metadata (F07). Optional for older blueprints. */
  description?: string;
  tags?: string[];
  /** Storage-agnostic image reference. Mirrors assetId for project assets. */
  image?: AssetReference | null;
}

export interface SymbolPlan {
  royals: number;
  medium: number;
  high: number;
  specials: Array<"wild" | "scatter" | "bonus">;
}

export const DEFAULT_SYMBOL_PLAN: SymbolPlan = {
  royals: 4,
  medium: 2,
  high: 3,
  specials: ["wild", "scatter", "bonus"],
};

export type BlendMode =
  | "normal"
  | "multiply"
  | "screen"
  | "overlay"
  | "darken"
  | "lighten"
  | "color-dodge"
  | "color-burn"
  | "hard-light"
  | "soft-light"
  | "difference"
  | "exclusion";

export interface LayerTransform {
  x: number;
  y: number;
  width?: number;
  height?: number;
  scaleX?: number;
  scaleY?: number;
  rotation?: number;
}

export interface LayerDef {
  id: string;
  name: string;
  kind: "background" | "reels" | "frame" | "ui" | "fx" | "overlay" | "custom" | "group";
  type?: string;
  order: number;
  visible: boolean;
  locked: boolean;
  opacity: number;
  blendMode?: BlendMode;
  transform?: LayerTransform;
  parentId?: string | null;
  groupId?: string | null;
  expanded?: boolean;
}

export interface CanvasLayout {
  width: number;
  height: number;
  safeArea: { top: number; right: number; bottom: number; left: number };
  orientation: "landscape" | "portrait" | "responsive";
  backgroundAssetId: string | null;
}

export type SceneObjectKind = "symbol" | "element" | "image" | "text" | "shape" | "stroke" | "group";
export type ShapeKind = "rect" | "ellipse" | "triangle";

/**
 * One positioned item on a scene. `x`/`y` are the unrotated top-left in scene
 * coordinates; `rotation` is in degrees about the object centre. Pure layout
 * data: it describes composition and is evaluated only by the SECTION 2 engine.
 */
export interface SceneObject {
  id: string;
  name: string;
  kind: SceneObjectKind;
  type?: string;
  layerId: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  opacity: number;
  visible: boolean;
  locked: boolean;
  blur: number;
  fill: string | null;
  stroke: string | null;
  strokeWidth: number;
  radius: number;
  shape: ShapeKind | null;
  /** stroke objects only: draws an arrowhead on the end point */
  arrow: boolean;
  /** freehand paths, normalised 0..1 within the object box so resize/rotate stay cheap */
  points: Array<{ x: number; y: number }>;
  text: string | null;
  fontSize: number;
  fontWeight: number;
  align: "left" | "center" | "right";
  /** symbol id or element id this object is an instance of */
  refId: string | null;
  assetId: string | null;
  blendMode?: BlendMode;
  transform?: LayerTransform;
  parentId?: string | null;
  groupId?: string | null;
  expanded?: boolean;
}

export interface SceneBackground {
  color: string | null;
  assetId: string | null;
}

export interface SceneDef {
  id: string;
  name: string;
  kind: "intro" | "base" | "freespins" | "bonus" | "outro";
  layerIds: string[];
  entryTransition: string;
  /** Scene layout owned by the canvas editor. */
  objects?: SceneObject[];
  background?: SceneBackground;
}

export interface ReelConfig {
  columns: number;
  rows: number;
  evaluation: "lines" | "ways" | "cluster";
  strips: string[][];
  spinDirection: "down" | "up";
}

export interface PaylineDef {
  id: string;
  index: number;
  /** row index per column */
  pattern: number[];
  active: boolean;
}

export interface PaytableEntry {
  symbolId: string;
  ofAKind: number;
  payout: number;
}

export interface FeatureConfig {
  id: string;
  name: string;
  kind: "free_spins" | "hold_and_win" | "pick_bonus" | "gamble" | "jackpot";
  enabled: boolean;
  params: Record<string, number | string | boolean>;
}

export interface AnimationMeta {
  id: string;
  target: string;
  trigger: "spin_start" | "reel_stop" | "win" | "big_win" | "feature_enter";
  kind: string;
  durationMs: number;
  easing: string;
}

export interface MathConfig {
  rtpTarget: number;
  volatility: Volatility;
  maxWinX: number;
  betLevels: number[];
  hitFrequency: number;
}

export interface ExportConfig {
  format: "blueprint-json";
  engineTarget: "section2-engine";
  includeAssets: boolean;
  minify: boolean;
}

/**
 * Immutable record of the manual creation draft. Live design state lives in
 * elements/symbols/symbolSets/assets and may diverge from this record.
 */
export interface BlueprintCreation {
  version: 1;
  mode: "manual";
  folderPath: string;
  gridPreset: "5x3" | "5x4" | "6x3" | "6x4" | "custom";
  stylePreset: "cinematic" | "cartoon" | "painterly" | "neon" | "flat" | "custom";
  symbolPlan: SymbolPlan;
  requestedPaylineCount: number;
  elements: {
    gameTitle: boolean;
    backgrounds: number;
    aspect: "16:9" | "21:9" | "3:2" | "4:3" | "9:16";
    reelFrames: number;
    frameStyle: "ornate" | "minimal" | "cabinet" | "themed";
    buttons: Array<"spin" | "max" | "auto" | "turbo" | "bet" | "menu">;
  };
  artwork: Array<{
    sourceId: string;
    assetId: string;
    elementType: ElementType;
    name: string;
    mime: string;
    width: number;
    height: number;
    bytes: number;
  }>;
  reference: {
    sourceId: string;
    assetId: string;
    name: string;
    mime: string;
    width: number;
    height: number;
    bytes: number;
  } | null;
  /** These are editor starter values, not certified or simulated engine math. */
  mathState: "unverified";
}

export interface GameBlueprint {
  version: number;
  /** Optional for blueprints created before F03. */
  creation?: BlueprintCreation;
  meta: ProjectMeta;
  style: ThemeStyle;
  symbols: SymbolDef[];
  symbolSets: SymbolSetDef[];
  specialSymbols: SpecialSymbolDef[];
  assets: AssetRef[];
  elements: ElementDef[];
  layers: LayerDef[];
  canvas: CanvasLayout;
  scenes: SceneDef[];
  reels: ReelConfig;
  paylines: PaylineDef[];
  paytable: PaytableEntry[];
  features: FeatureConfig[];
  animations: AnimationMeta[];
  math: MathConfig;
  exportConfig: ExportConfig;
  /**
   * Reserved, inert extension point for a future (SECTION 3) assistant.
   * The studio never writes to it and never requires it.
   */
  extensions: Record<string, unknown>;
}
