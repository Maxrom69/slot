"use client";

import type { CSSProperties } from "react";
import { Button } from "@/components/ui/Controls";
import { Icon } from "@/components/ui/Icon";
import { elementTypeMeta } from "@/lib/blueprint/elements";
import type { ElementDef, StylePalette, SymbolDef } from "@/lib/blueprint/types";
import { valueOfTier } from "@/lib/design/model";
import { elementImage, elementStatus, membersOf, symbolImage } from "@/lib/design/selectors";
import type { DesignDoc, Selection } from "@/lib/design/types";
import type { DesignActions } from "./actions";
import { SetTypeBadge, StatusBadge, TierBadge, TypeBadge } from "./Badges";
import { CommitInput } from "./CommitInput";
import { ElementThumb, SymbolThumb } from "./Thumb";

interface Props {
  doc: DesignDoc;
  element: ElementDef | null;
  palette: StylePalette;
  title: string;
  zoom: number;
  selection: Selection;
  actions: DesignActions;
  onBack: () => void;
}

function SymbolCard({ symbol, doc, palette, selected, setId, actions }: {
  symbol: SymbolDef; doc: DesignDoc; palette: StylePalette; selected: boolean; setId: string; actions: DesignActions;
}) {
  const has = Boolean(symbolImage(doc, symbol));
  const target = { kind: "symbol" as const, id: symbol.id };
  const btn = "focus-ring grid h-7 w-7 place-items-center rounded-md text-ink-300 transition hover:bg-white/10 hover:text-ink-100 disabled:cursor-not-allowed disabled:opacity-30";
  return (
    <article data-symbol-id={symbol.id} aria-label={`Symbol ${symbol.name}`} onClick={() => actions.select({ kind: "symbol", id: symbol.id, elementId: setId })}
      className={`rounded-xl border bg-ink-900 p-2 transition ${selected ? "border-accent-500/70 shadow-lg shadow-accent-600/10" : "border-white/[0.07] hover:border-white/20"}`}>
      <SymbolThumb doc={doc} symbol={symbol} palette={palette} className="aspect-square w-full rounded-lg" />
      <div className="mt-2 space-y-1.5" onClick={(event) => event.stopPropagation()}>
        <CommitInput value={symbol.name} label={`Name of ${symbol.name}`} className="h-7 py-0 text-[11.5px]" onCommit={(name) => actions.renameSymbol(symbol.id, name)} />
        <div className="flex items-center justify-between gap-1">
          <span className="font-mono text-[9.5px] text-ink-400" title={Object.entries(symbol.payouts).map(([k, v]) => `${k}× ${v}`).join(" · ")}>{symbol.code} · w{symbol.reelWeight}</span>
          <div className="flex items-center">
            <button type="button" className={btn} aria-label={`Replace image of ${symbol.name}`} title="Replace image" onClick={() => actions.replaceImage(target)}><Icon name="replace" size={13} /></button>
            <button type="button" className={btn} aria-label={`Download image of ${symbol.name}`} title={has ? "Download image" : "No image linked yet"} disabled={!has} onClick={() => actions.download(target)}><Icon name="download" size={13} /></button>
            <button type="button" className={btn} aria-label={`Delete ${symbol.name}`} title="Delete symbol" onClick={() => actions.requestDelete({ kind: "symbol", id: symbol.id })}><Icon name="trash" size={13} /></button>
          </div>
        </div>
      </div>
    </article>
  );
}

/** Detail workspace for one element. Same editor state as the overview, so history is shared. */
export function ElementDetail({ doc, element, palette, title, zoom, selection, actions, onBack }: Props) {
  if (!element) {
    return (
      <div className="mx-auto max-w-md px-6 py-20 text-center">
        <h2 className="text-[15px] font-semibold text-ink-100">Element not found</h2>
        <p className="mt-2 text-[12px] text-ink-400">It may have been deleted or the link is out of date.</p>
        <Button className="mt-5" variant="primary" onClick={onBack}><Icon name="arrow-left" size={13} />Back to Design</Button>
      </div>
    );
  }
  const isSet = element.type === "symbol_set";
  const members = membersOf(doc, element);
  const image = elementImage(doc, element);
  const withArt = members.filter((s) => symbolImage(doc, s)).length;
  const meta = elementTypeMeta(element.type);
  const symbol = element.type === "symbol" ? members[0] : undefined;

  return (
    <div className="mx-auto w-full max-w-[1400px] px-4 py-5 sm:px-6" style={{ "--tile": `${zoom}px` } as CSSProperties}>
      <nav aria-label="Breadcrumb" className="mb-4 flex items-center gap-1.5 text-[11px] text-ink-400">
        <button type="button" onClick={onBack} className="focus-ring flex items-center gap-1 rounded text-ink-300 hover:text-ink-100"><Icon name="arrow-left" size={12} />Design</button>
        <Icon name="chevron-right" size={11} /><span>{isSet ? "Symbol Sets" : "Standalone Elements"}</span>
        <Icon name="chevron-right" size={11} /><span className="text-ink-100">{element.name}</span>
      </nav>

      <header className="mb-5 flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0 flex-1 basis-72">
          <h2 className="sr-only">{element.name} detail</h2>
          <CommitInput value={element.name} label="Element name" className="max-w-md text-[16px] font-semibold" onCommit={(name) => actions.rename(element.id, name)} />
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            {isSet ? <><SetTypeBadge type={element.symbolSet?.symbolType ?? "custom"} /><TierBadge tier={element.symbolSet?.valueTier ?? "medium"} /></> : <TypeBadge element={element} />}
            <StatusBadge status={elementStatus(doc, element)} />
            {isSet ? <span className="font-mono text-[10.5px] text-ink-300">{members.length} symbols · {withArt} with artwork</span> : null}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {isSet ? (
            <>
              <Button onClick={() => actions.addSymbol(element.id)}><Icon name="plus" size={13} />Add symbol</Button>
              <Button variant="primary" onClick={() => actions.manageSet(element.id)}><Icon name="settings" size={13} />Manage set</Button>
              <Button onClick={() => actions.importIntoSet(element.id)}><Icon name="upload" size={13} />Import images</Button>
              <Button disabled={withArt === 0} title={withArt === 0 ? "No symbol images to download yet" : "Download every symbol image as a .zip"} onClick={() => actions.download({ kind: "element", id: element.id })}><Icon name="package" size={13} />Download .zip</Button>
            </>
          ) : (
            <>
              <Button onClick={() => actions.replaceImage({ kind: "element", id: element.id })}><Icon name="replace" size={13} />{image ? "Replace image" : "Add image"}</Button>
              <Button disabled={!image} onClick={() => actions.removeImage({ kind: "element", id: element.id })}><Icon name="x" size={13} />Remove</Button>
              <Button disabled={!image} onClick={() => actions.download({ kind: "element", id: element.id })}><Icon name="download" size={13} />Download</Button>
            </>
          )}
          <Button onClick={() => actions.duplicate(element.id)}><Icon name="copy" size={13} />Duplicate</Button>
          <Button variant="danger" onClick={() => actions.requestDelete({ kind: "element", id: element.id })}><Icon name="trash" size={13} />Delete</Button>
        </div>
      </header>

      {isSet ? (
        members.length === 0 ? (
          <div className="grid place-items-center rounded-xl border border-dashed border-white/10 px-6 py-16 text-center">
            <div className="max-w-xs"><p className="text-[13px] font-semibold text-ink-100">This set is empty</p>
              <p className="mt-1.5 text-[11.5px] text-ink-400">Add a placeholder symbol, or import images to create symbols with artwork.</p>
              <div className="mt-4 flex justify-center gap-2"><Button onClick={() => actions.importIntoSet(element.id)}><Icon name="upload" size={13} />Import images</Button><Button variant="primary" onClick={() => actions.addSymbol(element.id)}><Icon name="plus" size={13} />Add symbol</Button></div>
            </div>
          </div>
        ) : (
          <div className="grid gap-3" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(max(150px, var(--tile)), 1fr))" }}>
            {members.map((s) => <SymbolCard key={s.id} symbol={s} doc={doc} palette={palette} setId={element.id} actions={actions} selected={selection?.kind === "symbol" && selection.id === s.id} />)}
          </div>
        )
      ) : (
        <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_280px]">
          <ElementThumb doc={doc} element={element} palette={palette} title={title} className="aspect-[16/10] w-full rounded-xl border border-white/10" />
          <div className="space-y-3 rounded-xl border border-white/[0.07] bg-ink-900 p-4 text-[11.5px]">
            <h3 className="text-[10px] font-semibold tracking-[0.16em] text-ink-400 uppercase">About this element</h3>
            <p className="leading-relaxed text-ink-300">{meta.description}</p>
            <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1.5">
              <dt className="text-ink-400">Type</dt><dd className="text-right text-ink-200">{meta.label}</dd>
              <dt className="text-ink-400">Group</dt><dd className="truncate text-right text-ink-200">{element.group || "—"}</dd>
              <dt className="text-ink-400">Image</dt><dd className="truncate text-right text-ink-200">{image ? image.name : "None linked"}</dd>
              {symbol ? <><dt className="text-ink-400">Code</dt><dd className="text-right font-mono text-ink-200">{symbol.code}</dd><dt className="text-ink-400">Value</dt><dd className="text-right text-ink-200">{symbol.tier === "special" ? "Special" : valueOfTier(symbol.tier)}</dd></> : null}
              {Object.entries(element.params).map(([k, v]) => <div key={k} className="contents"><dt className="text-ink-400">{k}</dt><dd className="truncate text-right text-ink-200">{String(v)}</dd></div>)}
            </dl>
            {element.notes ? <p className="border-t border-white/[0.06] pt-3 leading-relaxed text-ink-300">{element.notes}</p> : null}
            <p className="border-t border-white/[0.06] pt-3 text-[10.5px] leading-relaxed text-ink-400">Edit properties and notes in the inspector on the right.</p>
          </div>
        </div>
      )}
    </div>
  );
}
