"use client";

import { useState } from "react";
import { Button } from "@/components/ui/Controls";
import { Icon } from "@/components/ui/Icon";
import { CommitInput } from "./CommitInput";
import type { AssetReference, SymbolVariant } from "@/lib/blueprint/types";

export function TagsInput({ value, onCommit, label }: { value: string[]; onCommit: (tags: string[]) => void; label: string }) {
  const [text, setText] = useState(value.join(", "));
  const [prev, setPrev] = useState(value);
  if (prev !== value) {
    setPrev(value);
    setText(value.join(", "));
  }
  const commit = () => {
    const tags = text.split(",").map((t) => t.trim().slice(0, 40)).filter(Boolean).slice(0, 12);
    if (tags.join("|") !== value.join("|")) onCommit(tags);
    else setText(value.join(", "));
  };
  return (
    <input
      aria-label={label}
      value={text}
      maxLength={200}
      placeholder="premium, night, …"
      onChange={(e) => setText(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          (e.target as HTMLInputElement).blur();
        } else if (e.key === "Escape") {
          e.stopPropagation();
          setText(value.join(", "));
          (e.target as HTMLInputElement).blur();
        }
      }}
      className="focus-ring w-full rounded-md border border-white/10 bg-ink-950/70 px-2.5 py-1.5 text-sm text-ink-100 placeholder:text-ink-400/70 transition hover:border-white/20"
    />
  );
}

const EXTRA_KEY = /^[A-Za-z][A-Za-z0-9_]{0,39}$/;

export function ExtrasEditor({
  value,
  onCommit,
}: {
  value: Record<string, number | string | boolean>;
  onCommit: (extras: Record<string, number | string | boolean>) => void;
}) {
  const entries = Object.entries(value);
  const [key, setKey] = useState("");
  const [error, setError] = useState<string | null>(null);
  return (
    <div>
      {entries.length === 0 ? (
        <p className="text-[10.5px] text-ink-400">No custom data. Keys are text, values are text, numbers or switches.</p>
      ) : (
        <ul className="space-y-1.5">
          {entries.map(([k, v]) => (
            <li key={k} className="flex items-center gap-1.5">
              <span className="min-w-0 flex-1 truncate rounded border border-white/10 bg-ink-950/60 px-2 py-1 font-mono text-[10.5px] text-ink-200" title={k}>
                {k}
              </span>
              {typeof v === "boolean" ? (
                <button
                  type="button"
                  role="switch"
                  aria-checked={v}
                  aria-label={`Extra ${k}`}
                  onClick={() => onCommit({ ...value, [k]: !v })}
                  className={`focus-ring relative h-5 w-9 shrink-0 rounded-full border transition ${v ? "border-accent-500/60 bg-accent-600" : "border-white/15 bg-ink-750"}`}
                >
                  <span className={`absolute top-0.5 h-3.5 w-3.5 rounded-full bg-white transition-all ${v ? "left-[18px]" : "left-0.5"}`} />
                </button>
              ) : typeof v === "number" ? (
                <input
                  aria-label={`Extra ${k} value`}
                  type="number"
                  value={v}
                  onChange={(e) => {
                    const n = Number(e.target.value);
                    if (e.target.value !== "" && Number.isFinite(n)) onCommit({ ...value, [k]: n });
                  }}
                  className="focus-ring w-24 shrink-0 rounded border border-white/10 bg-ink-950/60 px-2 py-1 font-mono text-[10.5px] text-ink-100"
                />
              ) : (
                <input
                  aria-label={`Extra ${k} value`}
                  value={v}
                  maxLength={300}
                  onChange={(e) => onCommit({ ...value, [k]: e.target.value.slice(0, 300) })}
                  className="focus-ring min-w-0 flex-1 rounded border border-white/10 bg-ink-950/60 px-2 py-1 text-[10.5px] text-ink-100"
                />
              )}
              <button
                type="button"
                aria-label={`Remove extra ${k}`}
                onClick={() => {
                  const next = { ...value };
                  delete next[k];
                  onCommit(next);
                }}
                className="focus-ring shrink-0 rounded p-1 text-ink-400 hover:text-rose-300"
              >
                <Icon name="x" size={12} />
              </button>
            </li>
          ))}
        </ul>
      )}
      <div className="mt-2 flex items-center gap-1.5">
        <input
          aria-label="New extra key"
          value={key}
          maxLength={40}
          placeholder="new_key"
          onChange={(e) => {
            setKey(e.target.value);
            setError(null);
          }}
          onKeyDown={(e) => {
            if (e.key !== "Enter") return;
            e.preventDefault();
            const k = key.trim();
            if (!EXTRA_KEY.test(k)) {
              setError("Keys start with a letter, using letters, numbers and _.");
              return;
            }
            if (k in value || entries.length >= 24) {
              setError(k in value ? "That key already exists." : "Up to 24 entries.");
              return;
            }
            onCommit({ ...value, [k]: "" });
            setKey("");
          }}
          className="focus-ring min-w-0 flex-1 rounded border border-white/10 bg-ink-950/60 px-2 py-1 font-mono text-[10.5px] text-ink-100 placeholder:text-ink-400/60"
        />
        <Button
          className="h-7 shrink-0 px-2 text-[10.5px]"
          onClick={() => {
            const k = key.trim();
            if (!EXTRA_KEY.test(k)) {
              setError("Keys start with a letter, using letters, numbers and _.");
              return;
            }
            if (k in value || entries.length >= 24) {
              setError(k in value ? "That key already exists." : "Up to 24 entries.");
              return;
            }
            onCommit({ ...value, [k]: "" });
            setKey("");
          }}
        >
          <Icon name="plus" size={12} />Add
        </Button>
      </div>
      {error ? <p role="alert" className="mt-1 text-[10.5px] text-rose-300">{error}</p> : null}
    </div>
  );
}

export function AssetRefPicker({
  label,
  value,
  assets,
  allowNone = true,
  onChange,
}: {
  label: string;
  value: AssetReference | null;
  assets: { id: string; name: string; state: string }[];
  allowNone?: boolean;
  onChange: (ref: AssetReference | null) => void;
}) {
  const current = value?.provider === "project" ? (value.assetId ?? "") : value?.provider === "external" ? "__external__" : "";
  const [external, setExternal] = useState(value?.provider === "external" ? (value.uri ?? "") : "");
  return (
    <div className="space-y-1.5">
      <select
        aria-label={label}
        value={current}
        onChange={(e) => {
          const v = e.target.value;
          if (!v) onChange(null);
          else if (v === "__external__") onChange({ provider: "external", uri: external || "" });
          else onChange({ provider: "project", assetId: v });
        }}
        className="focus-ring w-full rounded-md border border-white/10 bg-ink-950/70 px-2.5 py-1.5 text-sm text-ink-100 transition hover:border-white/20"
      >
        {allowNone ? <option value="">None (placeholder)</option> : null}
        {assets
          .filter((a) => a.state === "linked")
          .map((a) => (
            <option key={a.id} value={a.id}>
              {a.name}
            </option>
          ))}
        <option value="__external__">External URL…</option>
      </select>
      {current === "__external__" ? (
        <input
          aria-label={`${label} URL`}
          value={external}
          maxLength={500}
          placeholder="https://…"
          onChange={(e) => {
            setExternal(e.target.value);
            onChange({ provider: "external", uri: e.target.value.slice(0, 500) });
          }}
          className="focus-ring w-full rounded-md border border-white/10 bg-ink-950/70 px-2.5 py-1.5 font-mono text-[11px] text-ink-100 placeholder:text-ink-400/60"
        />
      ) : null}
    </div>
  );
}

export function VariantManager({
  variants,
  onAdd,
  onRename,
  onDuplicate,
  onRemove,
}: {
  variants: SymbolVariant[];
  onAdd: () => void;
  onRename: (id: string, name: string) => void;
  onDuplicate: (id: string) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <div>
      {variants.length === 0 ? (
        <p className="text-[10.5px] text-ink-400">No variants. Each variant keeps its own stable id.</p>
      ) : (
        <ul className="space-y-1.5">
          {variants.map((v) => (
            <li key={v.id} className="rounded-md border border-white/[0.07] bg-ink-950/40 p-2">
              <div className="flex items-center gap-1.5">
                <div className="min-w-0 flex-1">
                  <CommitInput value={v.name} label={`Variant ${v.name} name`} maxLength={80} onCommit={(name) => onRename(v.id, name)} />
                </div>
                <button type="button" aria-label={`Duplicate variant ${v.name}`} title="Duplicate variant (new stable id)" onClick={() => onDuplicate(v.id)} className="focus-ring rounded p-1.5 text-ink-400 hover:text-ink-100">
                  <Icon name="copy" size={13} />
                </button>
                <button type="button" aria-label={`Remove variant ${v.name}`} title="Remove variant" onClick={() => onRemove(v.id)} className="focus-ring rounded p-1.5 text-ink-400 hover:text-rose-300">
                  <Icon name="trash" size={13} />
                </button>
              </div>
              <p className="mt-1 truncate font-mono text-[9.5px] text-ink-400" title={v.id}>
                id: {v.id}
              </p>
            </li>
          ))}
        </ul>
      )}
      <Button className="mt-2 h-7 px-2.5 text-[11px]" onClick={onAdd}>
        <Icon name="plus" size={13} />Add variant
      </Button>
    </div>
  );
}
