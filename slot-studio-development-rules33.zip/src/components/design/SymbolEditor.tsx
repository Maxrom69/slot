"use client";

import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { useRouter } from "next/navigation";
import { Button, Field, Select } from "@/components/ui/Controls";
import { Icon, type IconName } from "@/components/ui/Icon";
import type { AssetReference, AssetRef, StylePalette, SymbolDef, SymbolSetType, SymbolTier, ValueTier } from "@/lib/blueprint/types";
import { glyphsForTheme } from "@/lib/blueprint/palette";
import { useDesignEditor } from "@/lib/client/useDesignEditor";
import { designDocFromBlueprint } from "@/lib/design/migrate";
import { tierOfValue, valueOfTier, VALUE_TIERS, SET_TYPES } from "@/lib/design/model";
import {
  addVariant, annotateImageRevision, duplicateVariant, editVariant, removeVariant,
  renameSymbol, restoreImageRevision, updateSymbol,
} from "@/lib/design/operations";
import type { SymbolPatch } from "@/lib/design/types";
import type { GameBlueprint } from "@/lib/blueprint/types";
import { assetOf } from "@/lib/design/selectors";
import { AssetRefPicker, ExtrasEditor, TagsInput, VariantManager } from "./ElementFields";
import { CommitInput, CommitTextArea } from "./CommitInput";
import { TierBadge } from "./Badges";

type RoleFlag = "regular" | "wild" | "scatter" | "bonus";

const ROLE_OPTIONS: { id: RoleFlag; label: string; hint: string; icon: IconName }[] = [
  { id: "regular", label: "Regular", hint: "Standard paying symbol", icon: "check" },
  { id: "wild", label: "Wild", hint: "Behaviour flag only", icon: "diamond" },
  { id: "scatter", label: "Scatter", hint: "Behaviour flag only", icon: "sparkles" },
  { id: "bonus", label: "Bonus", hint: "Behaviour flag only", icon: "gift" },
];

function roleOf(symbol: SymbolDef): RoleFlag {
  if (symbol.isBonus) return "bonus";
  if (symbol.isWild) return "wild";
  if (symbol.isScatter) return "scatter";
  return "regular";
}

function assetUri(ref: AssetReference | null | undefined, assets: AssetRef[]): string | null {
  if (!ref) return null;
  if (ref.provider === "project" && ref.assetId) return assets.find((a) => a.id === ref.assetId)?.uri ?? null;
  if (ref.provider === "external" && ref.uri) return ref.uri;
  return null;
}

function assetName(ref: AssetReference | null | undefined, assets: AssetRef[]): string {
  if (!ref) return "None";
  if (ref.provider === "project" && ref.assetId) return assets.find((a) => a.id === ref.assetId)?.name ?? ref.assetId;
  if (ref.provider === "external" && ref.uri) {
    try {
      const u = new URL(ref.uri);
      return u.pathname.split("/").filter(Boolean).pop() || u.hostname;
    } catch {
      return ref.uri.length > 32 ? `…${ref.uri.slice(-30)}` : ref.uri;
    }
  }
  return "Placeholder";
}

const SOURCE_LABEL: Record<NonNullable<SymbolDef["imageHistory"]>[number]["source"], string> = {
  create: "Created",
  import: "Imported",
  upload: "Uploaded",
  duplicate: "Duplicated",
  variant: "From variant",
  restore: "Restored",
};

const SOURCE_ICON: Record<NonNullable<SymbolDef["imageHistory"]>[number]["source"], IconName> = {
  create: "plus",
  import: "upload",
  upload: "upload",
  duplicate: "copy",
  variant: "copy",
  restore: "refresh-ccw",
};

function fmt(ts: string): string {
  if (!ts) return "—";
  try {
    const d = new Date(ts);
    if (isNaN(d.getTime())) return ts;
    return d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  } catch {
    return ts;
  }
}

interface SymbolEditorProps {
  project: { id: string; title: string; theme: string; revision: number };
  blueprint: GameBlueprint;
  symbolId: string;
  setId: string | null;
}

export function SymbolEditor({ project, blueprint, symbolId, setId }: SymbolEditorProps) {
  const router = useRouter();
  const initialDoc = designDocFromBlueprint(blueprint);
  const { doc, run, apply, canUndo, canRedo, undo, redo, pushToast } = useDesignEditor({
    projectId: project.id,
    initialDoc,
    initialRevision: project.revision,
    glyphs: glyphsForTheme(project.theme),
  });
  const symbol = doc.symbols.find((s) => s.id === symbolId) ?? null;
  const [editingNotes, setEditingNotes] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [imageNotes, setImageNotes] = useState("");
  const palette = blueprint.style.palette;

  useEffect(() => {
    const t = copiedId ? window.setTimeout(() => setCopiedId(null), 1200) : undefined;
    return () => { if (t) window.clearTimeout(t); };
  }, [copiedId]);

  const assets: AssetRef[] = doc.assets.filter((a) => a.kind === "image");
  const linkedAssets = assets.filter((a) => a.state === "linked").map((a) => ({ id: a.id, name: a.name, state: a.state }));
  const pickerAssets = assets.map((a) => ({ id: a.id, name: a.name, state: a.state }));
  const variants = symbol?.variants ?? [];
  const imgHistory = symbol?.imageHistory ?? [];
  const currentImageUri = symbol ? assetUri(symbol.image, assets) : null;
  const familyList = useMemo(() => {
    const seen = new Set<string>();
    for (const s of doc.symbols) if (s.family) seen.add(s.family);
    return Array.from(seen).sort();
  }, [doc.symbols]);

  if (!symbol) {
    return (
      <div className="grid h-dvh place-items-center bg-ink-950 text-center">
        <div>
          <p className="text-[15px] font-semibold text-ink-100">Symbol not found</p>
          <p className="mt-1 text-[12px] text-ink-400">It may have been deleted.</p>
          <Button className="mt-5" onClick={() => window.history.back()}>
            <Icon name="arrow-left" size={13} />Go back
          </Button>
        </div>
      </div>
    );
  }

  const applyPatch = (patch: SymbolPatch, label: string) => apply(label, (d) => updateSymbol(d, symbolId, patch));

  const setRole = (role: RoleFlag) => {
    applyPatch(
      role === "bonus" ? { isBonus: true, isWild: false, isScatter: false }
        : role === "wild" ? { isWild: true, isBonus: false, isScatter: false }
          : role === "scatter" ? { isScatter: true, isWild: false, isBonus: false }
            : { isWild: false, isScatter: false, isBonus: false },
      role === "regular" ? "Clear role flags" : `Set role to ${role}`,
    );
  };

  const copyId = (id: string) => {
    const done = () => setCopiedId(id);
    if (navigator.clipboard?.writeText) navigator.clipboard.writeText(id).then(done).catch(done);
    else done();
  };

  const ownerSet = symbol.symbolSetId ? doc.elements.find((e) => e.id === symbol.symbolSetId) : null;
  const isSpecial = symbol.tier === "special";

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-ink-950 text-ink-100">
      {/* Header */}
      <header className="flex flex-wrap items-center gap-x-4 gap-y-3 border-b border-white/[0.07] bg-ink-900/70 px-5 py-3">
        <button type="button" onClick={() => window.history.back()} className="focus-ring rounded-md border border-white/10 p-1.5 text-ink-300 hover:text-ink-100" aria-label="Back">
          <Icon name="arrow-left" size={15} />
        </button>
        <div className="min-w-0 flex-1">
          <CommitInput value={symbol.name} label="Symbol name" className="text-[19px] font-semibold" onCommit={(name) => apply("Rename symbol", (d) => renameSymbol(d, symbolId, name))} />
          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
            <TierBadge tier={valueOfTier(symbol.tier)} />
            {ownerSet ? <span className="rounded-md border border-white/10 bg-white/[0.03] px-1.5 py-0.5 text-[9.5px] text-ink-300">{ownerSet.name}</span> : null}
            <span className="font-mono text-[10.5px] text-ink-400">{symbol.code}</span>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <Button variant="ghost" onClick={undo} disabled={!canUndo} title="Undo (Ctrl/⌘ Z)" aria-label="Undo"><Icon name="undo" size={14} /></Button>
          <Button variant="ghost" onClick={redo} disabled={!canRedo} title="Redo (Ctrl/⌘ Shift Z)" aria-label="Redo"><Icon name="redo" size={14} /></Button>
        </div>
      </header>

      {/* Main layout */}
      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[300px_minmax(0,1fr)]">
        {/* Left: image preview + artwork */}
        <aside className="min-h-0 space-y-4 overflow-y-auto border-b border-white/[0.07] bg-ink-900/30 p-4 lg:border-b-0 lg:border-r">
          <section className="rounded-xl border border-white/[0.07] bg-ink-900/60 p-4">
            <h3 className="text-[10px] font-semibold tracking-[0.16em] text-ink-400 uppercase">Image preview</h3>
            <div className="relative mt-3 aspect-square w-full overflow-hidden rounded-lg border border-white/10" style={previewStyle(currentImageUri, palette)}>
              {!currentImageUri ? (
                <div className="grid h-full place-items-center text-[56px] font-bold text-[color:var(--glow)]">
                  {symbol.glyph}
                </div>
              ) : null}
            </div>
            <dl className="mt-3 space-y-1 text-[11px]">
              <MetaRow label="Asset">{currentImageUri ? assetName(symbol.image, assets) : "None (placeholder)"}</MetaRow>
              <MetaRow label="Reference">{symbol.image?.provider ?? "—"}</MetaRow>
            </dl>

            <div className="mt-3 space-y-3 border-t border-white/[0.06] pt-3">
              <Field label="Choose existing asset">
                <AssetRefPicker
                  label="Symbol image"
                  value={symbol.image ?? null}
                  assets={pickerAssets}
                  onChange={(ref) => { setImageNotes(""); applyPatch({ image: ref, imageNotes: "" }, ref ? "Link image" : "Clear image"); }}
                />
              </Field>
              <div className="flex gap-1.5">
                <Button className="h-7 px-2 text-[10.5px]" disabled={!symbol.image} onClick={() => applyPatch({ image: null, imageNotes: "" }, "Clear image")}>
                  <Icon name="x" size={12} />Clear
                </Button>
                <Button className="h-7 px-2 text-[10.5px]" disabled={imgHistory.length === 0} onClick={() => {
                  if (imgHistory.length > 0) apply("Restore previous image", (d) => restoreImageRevision(d, symbolId, imgHistory[0].id));
                }}>
                  <Icon name="refresh-ccw" size={12} />Restore previous
                </Button>
              </div>
              <Field label="Restore notes (optional)" hint="Recorded with the next restore">
                <CommitTextArea value={imageNotes} label="Restore notes" rows={2} maxLength={320} placeholder="Why this change?"
                  onCommit={(v) => setImageNotes(v)} />
              </Field>
            </div>
          </section>
        </aside>

        {/* Right: sections */}
        <div className="min-h-0 space-y-4 overflow-y-auto p-4">
          {/* 1. Symbol metadata */}
          <section className="rounded-xl border border-white/[0.07] bg-ink-900/50 p-4">
            <h3 className="text-[10px] font-semibold tracking-[0.16em] text-ink-400 uppercase">Symbol metadata</h3>
            <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Name"><CommitInput value={symbol.name} label="Symbol name" onCommit={(name) => applyPatch({ name }, "Rename symbol")} /></Field>
              <Field label="ID">
                <div className="flex items-center gap-1.5 rounded-md border border-white/10 bg-ink-950/70 px-2.5 py-1.5">
                  <code className="min-w-0 flex-1 truncate font-mono text-[11px] text-ink-200">{symbol.id}</code>
                  <button type="button" onClick={() => copyId(symbol.id)} aria-label={`Copy id ${symbol.id}`} className="focus-ring shrink-0 rounded p-0.5 text-ink-400 hover:text-ink-100">
                    <Icon name="copy" size={12} />
                  </button>
                </div>
              </Field>
              <Field label="Description" hint="Notes about this symbol">
                <CommitTextArea value={symbol.description ?? ""} label="Symbol description" placeholder="What is this symbol?" onCommit={(v) => applyPatch({ description: v }, "Update description")} />
              </Field>
              <Field label="Symbol type">
                <Select aria-label="Symbol type" className="creation-input" value={symbol.symbolType ?? "custom"} onChange={(e) => applyPatch({ symbolType: e.target.value as SymbolSetType }, "Change symbol type")}>
                  {SET_TYPES.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
                </Select>
              </Field>
              <Field label="Tier">
                <Select aria-label="Symbol tier" className="creation-input" value={valueOfTier(symbol.tier)} disabled={isSpecial} onChange={(e) => applyPatch({ tier: tierOfValue(e.target.value as ValueTier) as SymbolTier }, "Change symbol tier")}>
                  {VALUE_TIERS.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
                </Select>
              </Field>
              <Field label="Symbol family" hint="Free-form family group">
                <CommitTextArea value={symbol.family ?? ""} label="Symbol family" placeholder="e.g. shrine-totems" onCommit={(v) => applyPatch({ family: v || undefined }, "Update symbol family")} />
              </Field>
            </div>
          </section>

          {/* 2. Role flags */}
          <section className="rounded-xl border border-white/[0.07] bg-ink-900/50 p-4">
            <h3 className="text-[10px] font-semibold tracking-[0.16em] text-ink-400 uppercase">Role flags</h3>
            <p className="mt-1 text-[10.5px] text-ink-400">Configuration flags only — behaviour is evaluated by the SECTION 2 engine.</p>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {ROLE_OPTIONS.map((opt) => {
                const active = roleOf(symbol) === opt.id;
                return (
                  <button key={opt.id} type="button" onClick={() => setRole(opt.id)} aria-pressed={active}
                    className={`focus-ring flex flex-col items-start gap-1 rounded-lg border px-3 py-2 text-left transition ${
                      active
                        ? "border-accent-500/60 bg-accent-500/[0.1]"
                        : "border-white/10 hover:border-white/25 bg-ink-950/40"
                    }`}>
                    <span className={`flex items-center gap-1.5 text-[11px] font-medium ${active ? "text-ink-100" : "text-ink-200"}`}>
                      <Icon name={opt.icon} size={12} />{opt.label}
                    </span>
                    <span className="text-[9.5px] leading-snug text-ink-400">{opt.hint}</span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* 3. Variants */}
          <section className="rounded-xl border border-white/[0.07] bg-ink-900/50 p-4">
            <h3 className="text-[10px] font-semibold tracking-[0.16em] text-ink-400 uppercase">Custom variants</h3>
            <p className="mt-1 text-[10.5px] text-ink-400">Independently addressable. Each keeps its own stable id — duplicates get new ids.</p>
            <div className="mt-3">
              <VariantManager
                variants={variants}
                onAdd={() => {
                  const id = run("Add variant", (d) => {
                    const r = addVariant(d, symbolId, {});
                    return { doc: r.doc, value: r.id };
                  });
                  if (id) pushToast("Variant created with its own stable id", "success");
                }}
                onRename={(id, name) => apply("Rename variant", (d) => editVariant(d, symbolId, id, { name }))}
                onDuplicate={(id) => {
                  const newId = run("Duplicate variant", (d) => {
                    const r = duplicateVariant(d, symbolId, id);
                    return { doc: r.doc, value: r.id };
                  });
                  if (newId) pushToast("Variant duplicated with a new stable id", "success");
                }}
                onRemove={(id) => apply("Remove variant", (d) => removeVariant(d, symbolId, id))}
              />
            </div>
          </section>

          {/* 4. Extras */}
          <section className="rounded-xl border border-white/[0.07] bg-ink-900/50 p-4">
            <h3 className="text-[10px] font-semibold tracking-[0.16em] text-ink-400 uppercase">Extras</h3>
            <div className="mt-3">
              <ExtrasEditor value={symbol.extras ?? {}} onCommit={(extras) => applyPatch({ extras }, "Update extras")} />
            </div>
          </section>

          {/* 5. Math metadata */}
          <section className="rounded-xl border border-white/[0.07] bg-ink-900/50 p-4">
            <h3 className="text-[10px] font-semibold tracking-[0.16em] text-ink-400 uppercase">Math metadata</h3>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <Field label="Math ID" hint="Opaque id for the SECTION 2 engine">
                <CommitInput value={symbol.mathId ?? ""} label="Math id" allowEmpty maxLength={80} onCommit={(v) => applyPatch({ mathId: v || null }, "Update math id")} />
              </Field>
              <Field label="Code">
                <CommitInput value={symbol.code} label="Symbol code" onCommit={(v) => applyPatch({ code: v }, "Update code")} />
              </Field>
              <Field label="Glyph" hint="Fallback glyph when no image is linked">
                <CommitInput value={symbol.glyph} label="Symbol glyph" maxLength={12} onCommit={(v) => applyPatch({ glyph: v }, "Update glyph")} />
              </Field>
              <Field label="Tags" hint="Comma-separated, up to 12">
                <TagsInput value={symbol.tags ?? []} label="Symbol tags" onCommit={(tags) => applyPatch({ tags }, "Update tags")} />
              </Field>
            </div>
          </section>

          {/* 6. Image history */}
          <section className="rounded-xl border border-white/[0.07] bg-ink-900/50 p-4">
            <h3 className="text-[10px] font-semibold tracking-[0.16em] text-ink-400 uppercase">Image history</h3>
            <p className="mt-1 text-[10.5px] text-ink-400">Recorded versions of this symbol's image. Restore any previous revision — the restore is recorded too.</p>
            {imgHistory.length === 0 ? (
              <p className="mt-3 text-[11.5px] text-ink-400">No image revisions yet. Replace the image to start building history.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {imgHistory.map((rev, i) => {
                  const revUri = assetUri(rev.asset, assets);
                  const isCurrent = symbol.image === rev.asset;
                  const isEditing = editingNotes === rev.id;
                  return (
                    <li key={rev.id} className={`rounded-lg border p-2.5 transition ${isCurrent ? "border-accent-500/40 bg-accent-500/[0.05]" : "border-white/[0.07] bg-ink-950/30"}`}>
                      <div className="flex items-start gap-2.5">
                        <div className="h-11 w-11 shrink-0 overflow-hidden rounded-md border border-white/10" style={revStyle(revUri, palette)}>
                          {!revUri ? <div className="grid h-full place-items-center text-[13px] font-bold text-[color:var(--glow)]">{symbol.glyph}</div> : null}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="flex items-center gap-1 rounded-md border border-white/10 bg-white/[0.03] px-1.5 py-0.5 text-[9.5px] text-ink-300">
                              <Icon name={SOURCE_ICON[rev.source]} size={10} />{SOURCE_LABEL[rev.source]}
                            </span>
                            <span className="text-[9.5px] text-ink-400">{fmt(rev.createdAt)}</span>
                            {isCurrent ? <span className="rounded border border-accent-500/50 bg-accent-500/[0.15] px-1.5 py-0.5 text-[9px] text-accent-300">Current</span> : null}
                          </div>
                          {rev.asset ? <p className="mt-1 truncate font-mono text-[9.5px] text-ink-400">{assetName(rev.asset, assets)}</p> : <p className="mt-1 text-[9.5px] text-ink-500">No image</p>}
                          {isEditing ? (
                            <CommitTextArea value={rev.notes ?? ""} label={`Notes for revision ${rev.id}`} rows={2} maxLength={320} placeholder="Notes…"
                              onCommit={(v) => { setEditingNotes(null); apply("Update revision notes", (d) => annotateImageRevision(d, symbolId, rev.id, v)); }} />
                          ) : rev.notes ? (
                            <p className="mt-1 text-[10px] leading-relaxed text-ink-300">{rev.notes}</p>
                          ) : null}
                        </div>
                        <div className="flex shrink-0 gap-0.5">
                          <button type="button" disabled={isCurrent} onClick={() => apply("Restore image revision", (d) => restoreImageRevision(d, symbolId, rev.id))}
                            aria-label={isCurrent ? "Current image" : `Restore revision ${rev.id}`} title={isCurrent ? "Already the current image" : "Restore this revision"}
                            className="focus-ring grid h-7 w-7 place-items-center rounded text-ink-400 hover:bg-white/10 hover:text-ink-100 disabled:cursor-not-allowed disabled:opacity-30">
                            <Icon name="refresh-ccw" size={13} />
                          </button>
                          <button type="button" onClick={() => setEditingNotes(isEditing ? null : rev.id)} aria-label={`Edit notes for revision ${rev.id}`} title={rev.notes ? "Edit notes" : "Add notes"}
                            className="focus-ring grid h-7 w-7 place-items-center rounded text-ink-400 hover:bg-white/10 hover:text-ink-100">
                            <Icon name="pencil" size={13} />
                          </button>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}

function previewStyle(uri: string | null, palette: StylePalette): CSSProperties {
  if (!uri) {
    return { background: `radial-gradient(120% 100% at 50% 0%, ${palette.accent}22, ${palette.surface} 60%, ${palette.background})` };
  }
  return {
    backgroundImage: `url("${uri}")`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  };
}
function revStyle(uri: string | null, palette: StylePalette): CSSProperties {
  if (!uri) return { background: `radial-gradient(110% 100% at 50% 0%, ${palette.accent}2e, ${palette.surface} 55%, ${palette.background})` };
  return { backgroundImage: `url("${uri}")`, backgroundSize: "cover", backgroundPosition: "center" };
}

function MetaRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <dt className="text-ink-400">{label}</dt>
      <dd className="min-w-0 text-right text-ink-200">{children}</dd>
    </div>
  );
}
