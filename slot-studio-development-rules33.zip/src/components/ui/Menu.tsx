"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";

export interface MenuItem {
  key: string;
  label: string;
  hint?: string;
  danger?: boolean;
  disabled?: boolean;
  disabledReason?: string;
  onSelect: () => void;
}

interface MenuProps {
  items: MenuItem[];
  label?: string;
  trigger?: ReactNode;
  align?: "left" | "right";
}

export function Menu({ items, label = "More actions", trigger, align = "right" }: MenuProps) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div ref={rootRef} className="relative">
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={label}
        onClick={(event) => {
          event.stopPropagation();
          event.preventDefault();
          setOpen((v) => !v);
        }}
        className="focus-ring grid h-7 w-7 place-items-center rounded-md border border-white/10 bg-ink-850/90 text-ink-300 transition hover:border-white/20 hover:text-ink-100"
      >
        {trigger ?? <span className="text-[13px] leading-none">⋯</span>}
      </button>
      {open ? (
        <div
          role="menu"
          className={`animate-fade-in absolute z-40 mt-1 min-w-[190px] overflow-hidden rounded-lg border border-white/10 bg-ink-850 py-1 shadow-xl shadow-black/60 ${
            align === "right" ? "right-0" : "left-0"
          }`}
        >
          {items.map((item) => (
            <button
              key={item.key}
              type="button"
              role="menuitem"
              disabled={item.disabled}
              title={item.disabled ? item.disabledReason : undefined}
              onClick={(event) => {
                event.stopPropagation();
                event.preventDefault();
                if (item.disabled) return;
                setOpen(false);
                item.onSelect();
              }}
              className={`flex w-full items-center justify-between gap-6 px-3 py-1.5 text-left text-xs transition ${
                item.disabled
                  ? "cursor-not-allowed text-ink-400/60"
                  : item.danger
                    ? "text-rose-300 hover:bg-rose-500/10"
                    : "text-ink-200 hover:bg-white/5 hover:text-ink-100"
              }`}
            >
              <span>{item.label}</span>
              {item.hint ? (
                <span className="font-mono text-[10px] text-ink-400">{item.hint}</span>
              ) : null}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}
