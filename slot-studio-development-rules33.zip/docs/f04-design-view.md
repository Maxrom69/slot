# F04 — Design view

The Design view is the visual asset-management workspace. It stores **composition and configuration** in the Game Blueprint. It does not evaluate, simulate or play a game; reel strips, paytable rows, payouts and weights are declarative starter configuration for the SECTION 2 engine.

## Routes
- `/projects/[id]` — Design view (default for *Open* and for a newly created project).
- `/projects/[id]?element=<id>` — the same view in an element's detail workspace. Deep-linkable; browser back/forward work; an unknown id shows "Element not found".
- `/projects/[id]/settings` (`?tab=blueprint`) — the F02/F03 overview, metadata editor and blueprint JSON, unchanged.

## Layout
Left: project context, navigation, an outline of all elements, blueprint status, export. Center: the element workspace. Right: the contextual inspector. Top: project title, save state, undo/redo, zoom, grid/list, Import, Add Element.
Below 1280 px the inspector becomes a drawer (toggle in the top bar); below 1024 px the left navigation does too. Both are removed from the tab order while closed.

## Organisation
- **Symbol Sets** — expandable groups. Each shows name, symbol type (Character, Royals, Suits, 7, BAR, Custom), value tier (Low/Medium/High), status, symbol count and thumbnails. Collapsed groups show a thumbnail strip; expanded groups show a tile per symbol. Expansion state, zoom and view mode persist per project in the browser.
- **Standalone Elements** — Game Title, Game Background, Reel Frame, Button Set, standalone Symbols (including Wild/Scatter/Bonus), Uploaded art and Other, with type filters and grid/list view.
- Status is derived, never stored: *Empty*, *Planned* (no artwork), *Partial*, *Ready*.

## Actions
Hover/focus toolbar on every element: Edit, Replace image, Duplicate, Delete, Download, Open detail. Anything that cannot apply is disabled with a reason (e.g. a set has no single image; nothing to download yet). "Regenerate with AI" and "Generate variations" appear only as **disabled, reserved** items; nothing AI exists.
Add Element offers Symbol Set, Symbol, Game Title, Reel Frame, Game Background, Button Set and Other / Uploaded Asset, each with its own options and an optional image. Import takes many local files, maps each to an element type (guessed from the filename, always changeable) and groups files typed "Symbol Set" into one new set. Files can also be dropped anywhere on the workspace.
Symbol sets download as a `.zip` of their images plus `set.json`; other elements download their image.

Shortcuts: `Ctrl/⌘ Z`, `Ctrl/⌘ Shift Z` / `Ctrl Y`, `Ctrl/⌘ S`, `N` add, `/` search, `↑/↓` move selection, `←/→` collapse/expand a set, `Enter` open detail, `F2` rename, `Ctrl/⌘ D` duplicate, `Delete` delete (confirmation), `Esc` back / clear.

## Architecture
- `lib/design/model.ts` — `finalizeDoc`: restores every invariant after an edit (single owner per symbol, no dangling references, reel strips rebuilt only when symbols appear/disappear, paytable rows follow symbols, unreferenced images pruned, style reference protected). Pure and idempotent; the client and server run the same function.
- `lib/design/operations.ts` — every edit as a pure function `(doc, args) -> doc` (add, rename, update, duplicate, delete, images, symbols, import). These are the unit of undo/redo and can be replayed from serialised input.
- `lib/design/migrate.ts` — `DesignDoc` ⇄ blueprint, and an idempotent upgrade of older blueprints (sets gain a type + tier, mixed medium/high sets are split, specials become standalone symbols, imported symbol art becomes a real symbol).
- `lib/design/parse.ts` — strict validation of untrusted design data. `lib/design/history.ts` — snapshot undo/redo with typing coalescing. `lib/design/zip.ts` — dependency-free ZIP writer.
- `lib/client/useDesignEditor.ts` — editor state, history, debounced autosave, uploads.
- `components/design/*` — presentation only; `DesignApp` wires state to UI through one `DesignActions` interface.

## Persistence
`PUT /api/projects/[id]/design` saves the design slice of the blueprint inside a row-locked transaction. Only the slice is merged, so title/folder edits elsewhere are preserved. Every save carries the revision it was based on: a stale writer gets **409**, and the UI offers *Reload latest* or *Overwrite with my version*. Broken references are rejected (422); unfinished work (for example, no symbols) is allowed and reported as completeness items. Linked artwork must be an image stored for the project (`POST /api/projects/[id]/assets`, PNG/JPEG/WebP verified by header, 3 MB each, 64 MB per project). Autosave runs 800 ms after an edit, saves are serialised, edits made mid-save are never lost, and leaving the page asks first if a save failed.
The dashboard thumbnail follows the first background that has artwork.

## Known limits
- Replaced or deleted images stay in storage (undo needs them) and are not garbage-collected. A duplicated project shares image rows with its original.
- Reel strips are regenerated deterministically from symbol weights when symbols are added or removed; a strip editor will own them later.
- Undo history lives in the open tab and starts fresh after a reload; autosave means reloading never loses saved work, but an edit made in the last 800 ms before a hard reload is not saved (the browser's unsaved-changes prompt guards this).
- Standalone detail pages show the large preview and facts; their properties are edited in the inspector.

## Tests
- `tests/design.test.ts` (with `tests/creation.test.ts`): `npm exec --yes --package=tsx -- tsx --test tests/design.test.ts tests/creation.test.ts`.
- `tests/design.browser.mjs`: real Chromium acceptance run against `BASE_URL` (default `http://localhost:3000`; set `PLAYWRIGHT_MODULE` to the runner's `playwright/index.mjs`). It creates its own project, exercises every action above including conflicts and server-side rejections, checks three viewport widths, and cleans up after itself.
