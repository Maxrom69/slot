# F03 — Manual project creation

## Routes
- `/games/new`: manual creation, with a reserved Agent information tab.
- `/projects/[id]`: opens on Design, an element preview/inspector. Element editing remains explicitly unavailable; metadata editing, export, and the overview are preserved.
- `/games`: dashboard; persisted project index refreshes on navigation restoration and workspace-change events.

## Service boundaries
- `lib/creation/draft.ts`: typed form model, catalogs, normalization, input checks, and validation.
- `lib/creation/blueprint-from-draft.ts`: pure conversion to a `GameBlueprint`. `blueprint.creation` keeps choices that rendering data alone cannot recover, including custom-grid selection, disabled element options, symbol counts, artwork dimensions, and the requested payline count when ways/cluster is selected.
- `lib/blueprint/validate.ts`: structural reference/geometry checks. These do not certify RTP or execute a game.
- `lib/client/useDraftEditor.ts`: immutable undo/redo with typing coalescing and full draft autosave. Ctrl/Cmd-Z, Shift-Ctrl/Cmd-Z, Ctrl-Y, Ctrl/Cmd-S, Ctrl/Cmd-Enter are supported.
- `lib/client/draft-store.ts`: IndexedDB draft document containing both form data and its blueprint, including artwork. Existing localStorage drafts migrate automatically. Saves are ordered; successful creation clears only after earlier saves finish. A full-document localStorage fallback is attempted if IndexedDB is unavailable. No artwork is silently stripped; storage failure is shown.
- `server/workspace-service.ts`: actual PostgreSQL persistence via Drizzle. New folders, artwork records, and the project are written in a single transaction. Invalid input does not leave partial folders or projects.
- `server/artwork.ts`: checks supported raster headers against declared MIME before storage.

## Artwork policy
PNG, JPEG, and WebP only. Source files up to 15 MB are decoded and downsized to at most 1600 pixels on the longest side (smaller if necessary), preserving alpha. Stored images are limited to 3 MB each and combined project artwork to 24 MB. Artwork is served by `/api/assets/[id]`.

Every import is assigned one of the seven documented element categories. Title, background, reel frame and button set art links to matching planned elements. Imported symbol art becomes a real standalone symbol, and imported symbol-set art becomes a symbol inside a set (see `docs/f04-design-view.md`; older projects are upgraded when read).

Reference art is a style reference, not a generation input. The layout preview is deterministic and non-playable. Math values and reel weights are declarative starter configuration, not simulated or verified engine output.

## Reserved Agent tab
Displays “AI Assistant — Coming Soon.” There are no agent implementations, chat inputs, model calls, simulated messages, billing, or generation workflows. `lib/creation/providers.ts` is an inert registry for a future provider. All project creation uses Manual.

## Tests
Run model regression tests with `npm exec --yes --package=tsx -- tsx --test tests/creation.test.ts`.

`tests/creation.browser.mjs` runs a real Chromium acceptance flow against `BASE_URL` (default `http://localhost:3000`). Point `PLAYWRIGHT_MODULE` at the test runner's `playwright/index.mjs` if Playwright is provided externally. The test creates and soft-deletes its own project and removes its empty test folders. It covers imports exceeding the old localStorage quota, restoration, presets/custom grids, undo/redo, cancel/resume, download, single submission, Design opening, dashboard refresh, responsive widths, and invalid input rollback.
